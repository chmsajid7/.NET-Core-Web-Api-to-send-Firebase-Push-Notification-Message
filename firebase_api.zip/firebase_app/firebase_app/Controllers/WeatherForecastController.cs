﻿using Microsoft.AspNetCore.Mvc;
using Nancy.Json;
using System;
using System.IO;
using System.Net;

namespace firebase_app.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        [Route("send_push_notification")]
        [HttpGet]
        public IActionResult SendMessage()
        {
            try
            {
                string server_api_key = "<server_api_key>";
                string sender_id = "<sender_id>";

                dynamic data = new
                {
                    // if you want to test for single device
                    to = "<your_web_app_token_that_you_got_from_browser's_console>",

                    // registration_ids = singlebatch, // this is for multiple user 
                    
                    notification = new
                    {
                        // Notification title
                        title = "My Notification title",

                        // Notification body data
                        body = "My Notification body",    

                        // When click on notification user redirect to this link
                        link = "https://www.dynagroseed.com/app/uploads/2018/02/testing-clipart-quiet-testing-sign-v0ryt0-297x300.jpg",
                        
                        //icon for notification
                        //icon: "https://www.dynagroseed.com/app/uploads/2018/02/testing-clipart-quiet-testing-sign-v0ryt0-297x300.jpg"
                    }
                };

                var serializer = new JavaScriptSerializer();
                var json = serializer.Serialize(data);
                Byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(json);

                WebRequest tRequest;
                tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                tRequest.Method = "post";
                tRequest.ContentType = "application/json";
                tRequest.Headers.Add(string.Format("Authorization: key={0}", server_api_key));

                tRequest.Headers.Add(string.Format("Sender: id={0}", sender_id));

                tRequest.ContentLength = byteArray.Length;
                Stream dataStream = tRequest.GetRequestStream();
                dataStream.Write(byteArray, 0, byteArray.Length);
                dataStream.Close();

                WebResponse tResponse = tRequest.GetResponse();

                dataStream = tResponse.GetResponseStream();

                StreamReader tReader = new StreamReader(dataStream);

                String sResponseFromServer = tReader.ReadToEnd();

                tReader.Close();
                dataStream.Close();
                tResponse.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return Ok();
        }
    }
}
